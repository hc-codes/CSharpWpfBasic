﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Text;
using System.Windows.Input;
using WpfMVVMStudent.Commands;
using WpfMVVMStudent.Model;

namespace WpfMVVMStudent.ViewModel
{
  
    public class StudentViewModel : INotifyPropertyChanged
    {
        private Student _student;
        private ObservableCollection<Student> _students;  //Students Collection 
        private ICommand _SubmitCommand;

        /// <summary>
        /// Constructor
        /// </summary>
        public StudentViewModel()
        {
            Student = new Student();
            Students = new ObservableCollection<Student>();
        }
        public Student Student
        {
            get { return _student; }
            set { _student = value; NotifyPropertyChanged("Student"); }
        } // Property

        public ObservableCollection<Student> Students //Property to notify change
        {
            get { return _students; }
            set
            {
                _students = value;
                NotifyPropertyChanged("Students");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// Notify Property Change  Method
        /// </summary>
        /// <param name="propertyName"></param>
        protected void NotifyPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
        public ICommand SubmitCommand //Readonly property
        {
            get
            {
                if (_SubmitCommand == null)
                {
                    _SubmitCommand = new RelayCommand(SubmitExecute, CanSubmitExecute, false);
                }
                return _SubmitCommand;
            }
        }
        private void SubmitExecute(object parameter)
        {
            Students.Add(Student);
        }
        private bool CanSubmitExecute(object parameter)
        {
            if (string.IsNullOrEmpty(Student.Name))
            {
                return false;
            }
            else
            {
                return true;
            }
        }
    }
}
