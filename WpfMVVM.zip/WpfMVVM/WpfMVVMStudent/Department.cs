﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WpfMVVMStudent
{
    public enum Department
    {
        CSE,
        ECE,
        EEE,
        ME
    }
}
